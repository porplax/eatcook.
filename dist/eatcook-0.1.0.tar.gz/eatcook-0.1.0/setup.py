# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['eatcook']
install_requires = \
['colorama>=0.4.5,<0.5.0', 'shellingham>=1.5.0,<2.0.0', 'typer>=0.6.1,<0.7.0']

setup_kwargs = {
    'name': 'eatcook',
    'version': '0.1.0',
    'description': "#Simple HTTP Server\n|Eatcook is a command line tool for starting socket servers.\n|\n|`py -m eatcook --host (HOST) --port (PORT) --folder (FOLDER)`\n|\n|(FOLDER) is where eatcook will get its html and python files (and routebook.json).\n\n|# Features\n|*Routebook*\n|Routebook is used to redirect users to pages.\n|A key is created like this: \n|```\n|{\n|    '/', 'index.html'\n|}\n|```\n|\n|\n|Eatcook will look for routebook and is required. \n|\n|\n|**FUN-FACT**: Eatcook can also run python files! Try it!\n",
    'long_description': None,
    'author': 'Zayne Marsh',
    'author_email': 'saynemarsh9@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
